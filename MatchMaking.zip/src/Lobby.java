package TronPackage;


public class Lobby  {

    private int map_ID;
    
    private int num_of_players;
    private int num_of_ai1;
    private int num_of_ai2;
    public Lobby(){

    }
    public Lobby(int map_ID,int num_of_players,int num_of_ai1,int num_of_ai2){
        this.map_ID=map_ID;
        
        this.num_of_players=num_of_players;
        this.num_of_ai1=num_of_ai1;
        this.num_of_ai2=num_of_ai2;
    }
    public int getMap_ID(){
        return map_ID;
    }
    
    public int getNum_of_players(){
        return num_of_players;
    }
    public int getNum_of_ai1(){
        return num_of_ai1;
    }
    public int getNum_of_ai2(){
        return num_of_ai2;
    }
    

    public void setMap_ID(int map_ID) {
        this.map_ID = map_ID;
    }

    public void setNum_of_players(int num_of_players) {
        this.num_of_players = num_of_players;
    }
    public void setNum_of_ai1(int num_of_ai1){
        this.num_of_ai1=num_of_ai1;
    }
    public void setNum_of_ai2(int num_of_ai2){
        this.num_of_ai2=num_of_ai2;
    }
    public void display_lobby(){
        System.out.println(map_ID);
        
        System.out.println(num_of_players);
        System.out.println(num_of_ai1);
        System.out.println(num_of_ai2);
    }
}
