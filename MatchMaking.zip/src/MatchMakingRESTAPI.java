package TronPackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


@Path("/MatchMaking")
@Singleton
public class MatchMakingRESTAPI {
	ExistingGames exG = new ExistingGames();
	UniqueID ui=new UniqueID();
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/PutCreateGame")
	public String create_new_game(@QueryParam("UserID")String userID) {
        User U=new User(userID);
        
        int gameID=ui.createID();
        Lobby l = new Lobby(0,0,0,0);
        Game g = new Game(gameID, "Created", U, l);
        g.human_players.add(U);
        g.setHost(U);
        for(int i=0;i<g.human_players.size();i++){
            if(g.human_players.get(i).getUser_ID()==userID){
        g.human_players.get(i).setUser_state("Ready");}
        }

        exG.games.add(g);
        
        return "<h1>" + gameID+ "</h1>";
    }
	
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/JoinGame")
	public String joinGame(@QueryParam("GameID") int gameID,@QueryParam("UserID") String userID) {
		userID="murad";
		User U=new User(userID);
        for(int i=0;i<exG.games.size();i++){
            if(exG.games.get(i).getGame_ID()==gameID){
                exG.games.get(i).human_players.add(U);
                exG.games.get(i).allPlayers.add(U);
            }
        }
        for(int i=0;i<exG.games.size();i++){
            if(exG.games.get(i).getGame_ID()==gameID){
                for(int j=0;j<exG.games.get(i).human_players.size();j++){
                    if(exG.games.get(i).human_players.get(j).getUser_ID()==userID){
                        exG.games.get(i).human_players.get(j).setUser_state("Ready");
                    }
                }
            }
        }        
                                 
        return "";
    }
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostKickPlayer")
	public String removePlayer(@QueryParam("PlayerID") String userID, int gameID) {
        
        for(int i=0;i<exG.games.size();i++){
            if(exG.games.get(i).getGame_ID()==gameID){
            	for(int j=0;j<exG.games.get(i).allPlayers.size();j++) {
                if(exG.games.get(i).allPlayers.get(j).getUser_ID()==userID) {
                exG.games.get(i).allPlayers.remove(j);
            }}
        }}
        for(int i=0;i<exG.games.size();i++){
            if(exG.games.get(i).getGame_ID()==gameID){
            	for(int j=0;j<exG.games.get(i).human_players.size();j++) {
                if(exG.games.get(i).human_players.get(j).getUser_ID()==userID) {
                exG.games.get(i).human_players.remove(j);
            }}
        }}
        return "200 OK";
    }
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostChangeColor")
	public String changeColor(@QueryParam("color") String color, @QueryParam("UserID") String userID) {
		for(int i=0;i<exG.games.size();i++) {
			for(int j=0;j<exG.games.get(i).allPlayers.size();j++) {
			if(exG.games.get(i).allPlayers.get(j).getUser_ID()==userID&&!exG.games.get(i).allPlayers.get(j).getColor().toString().equals(color)) {
				
			}
		}}
		return "200 OK";
		
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostChangeMap")
	public String changeMap(@QueryParam("MapID") int mapID,@QueryParam("UserID") String userID) {
		for(int i=0;i<exG.games.size();i++) {
			for(int j=0;j<exG.games.get(i).allPlayers.size();j++) {
				if(exG.games.get(i).allPlayers.get(j).getUser_ID()==userID) {
					exG.games.get(i).getLobby().setMap_ID(mapID);
				}
			}}		
		return "200 OK";
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostChangeNumOfPlayers")
	public String changeNumOfPlayers(@QueryParam("NumofPlayersID") int numOfPlayers,@QueryParam("UserID") String userID) {
		for(int i=0;i<exG.games.size();i++) {
			for(int j=0;j<exG.games.get(i).allPlayers.size();j++) {
				if(exG.games.get(i).allPlayers.get(j).getUser_ID()==userID) {
					exG.games.get(i).getLobby().setNum_of_players(numOfPlayers);;
				}
			}}		

		return "200 OK";
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostIAmReady")
	public String postIAmReady(@QueryParam("UserID") String userID) {
		for(int i=0;i<exG.games.size();i++) {
			for(int j=0;j<exG.games.get(i).allPlayers.size();j++) {
				if(exG.games.get(i).allPlayers.get(j).getUser_ID()==userID) {
					exG.games.get(i).allPlayers.get(j).setUser_state("Ready");;
				}
			}}		

		return "200 OK";
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostAddAI1")
	public String addAI1(@QueryParam("GameID") int gameID) throws IOException {
		URL userAuthURL = new URL("https://userauth-dot-trainingprojectlab2019.appspot.com/RegisterAI?GameID=" + gameID);
		HttpURLConnection userAuthConnection = (HttpURLConnection) userAuthURL.openConnection();
		userAuthConnection.setRequestMethod("POST");
		userAuthConnection.connect();
        int userAuthURLResponse = userAuthConnection.getResponseCode();
        if (userAuthURLResponse != 200) {
            throw new RuntimeException("HTTPResponseCode:" + userAuthURLResponse);}
        BufferedReader userAuthJson = new BufferedReader(new InputStreamReader(userAuthConnection.getInputStream()));
        AIbot bot = new Gson().fromJson(userAuthJson , AIbot.class);
        String UserID=bot.userID;
        String Token=bot.token;
        AIInput ai=new AIInput();
        ai.user_ID=UserID;
        ai.game_ID=gameID;
        ai.token=Token;
        URL AI1URL=new URL("https://ai1-dot-trainingprojectlab2019.appspot.com/ai-bot?ai"+ai);
        HttpURLConnection AI1Connection = (HttpURLConnection) AI1URL.openConnection();
        AI1Connection.setRequestMethod("POST");
        AI1Connection.connect();
        int AI1URLResponse = AI1Connection.getResponseCode();
        if (AI1URLResponse != 200) {
            throw new RuntimeException("HTTPResponseCode:" + AI1URLResponse);}
        
        
        
        
        
        
        
		return "200 OK";
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/PostAddAI2")
	public String addAI2(@QueryParam("GameID") int gameID) throws IOException {
		URL userAuthURL = new URL("https://userauth-dot-trainingprojectlab2019.appspot.com/RegisterAI?GameID=" + gameID);
		HttpURLConnection userAuthConnection = (HttpURLConnection) userAuthURL.openConnection();
		userAuthConnection.setRequestMethod("POST");
		userAuthConnection.connect();
        int userAuthURLResponse = userAuthConnection.getResponseCode();
        if (userAuthURLResponse != 200) {
            throw new RuntimeException("HTTPResponseCode:" + userAuthURLResponse);}
        BufferedReader userAuthJson = new BufferedReader(new InputStreamReader(userAuthConnection.getInputStream()));
        AIbot bot = new Gson().fromJson(userAuthJson , AIbot.class);
        String UserID=bot.userID;
        String Token=bot.token;
        AIInput ai=new AIInput();
        ai.user_ID=UserID;
        ai.game_ID=gameID;
        ai.token=Token;
        URL AI2URL=new URL("https://ai2-dot-trainingprojectlab2019.appspot.com/ai-bot?ai"+ai);
        HttpURLConnection AI2Connection = (HttpURLConnection) AI2URL.openConnection();
        AI2Connection.setRequestMethod("POST");
        AI2Connection.connect();
        int AI2URLResponse = AI2Connection.getResponseCode();
        if (AI2URLResponse != 200) {
            throw new RuntimeException("HTTPResponseCode:" + AI2URLResponse);}
        
        
        
        
        
        
        
		return "200 OK";
	}
	@GET
    @Path("/GetLobbyState")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLobbyState(@QueryParam("GameID") int gameID) {
        Game g = null;
        String lobbyStateJSON;
        for (Game game : exG.games
        ) {
            if (game.getGame_ID() == gameID) {
                g = game;
                break;
            }
        }
        if (g != null) {
            Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();
            lobbyStateJSON = gson.toJson(g.getLobby());
            return lobbyStateJSON;
        }
        return null;
    }
	@GET
    @Path("/GetListOfGames")
    @Produces(MediaType.TEXT_HTML)
    public String getListOfGames() {
       
        String listOfGamesJSON;
        
        
            Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create();
            listOfGamesJSON = gson.toJson(exG.games);
            return listOfGamesJSON;
       
    }
	
	
	
}