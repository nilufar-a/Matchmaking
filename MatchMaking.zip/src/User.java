package TronPackage;

public class User {
	

	
	    private String user_ID;
	    private String user_state="Not ready";
	     Color color;
	    enum  Color{
	        red,
	        yellow,
	        white,
	        black,
	        purple,
	        green,
	        blue,
	        orange,
	        brown,
	        grey
	    };
	    public Color getColor() {
	    	return color;
	    }
	    
	    public void setColor(Color color) {
	    	this.color = color;
	    }
	    
	    public User(){ }
	    public User(String user_ID){
	        this.user_ID=user_ID;
	    }
	    public String getUser_ID(){
	        return user_ID;
	    }

	    public void setUser_ID(String user_ID) {
	        this.user_ID = user_ID;
	    }
	    public String getUser_state(){
	        return user_state;
	    }

	    public void setUser_state(String user_state) {
	        this.user_state = user_state;
	    }

	

}
