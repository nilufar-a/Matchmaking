package TronPackage;

import java.util.ArrayList;

public class ExistingGames {
    public ArrayList<Game> games;
    public ExistingGames(){
        games=new ArrayList<>();
    }
}
