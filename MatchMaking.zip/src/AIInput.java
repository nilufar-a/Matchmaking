package TronPackage;

public class AIInput {
String user_ID;
String token;
int game_ID;
}
