package TronPackage;

public class AIbot extends User{
String userID;
String token;
}
